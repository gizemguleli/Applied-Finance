#ifndef GETONEGAUSSIANBYBOXMUELLER_H
#define GETONEGAUSSIANBYBOXMUELLER_H

double getOneGaussianByBoxMueller();
       
#endif

