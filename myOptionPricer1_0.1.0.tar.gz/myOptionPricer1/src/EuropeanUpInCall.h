#include<iostream>
#include<cmath>
#include"getOneGaussianByBoxMueller.h"

class EuropeanUpInCall {
public:
    // Constructor
    EuropeanUpInCall(
        int nInt_,
        double strike_,
        double barrier_,
        double spot_,
        double vol_,
        double r_,
        double expiry_
    );

    // Destructor
    ~EuropeanUpInCall() {};

    // Methods
    void generatePath();
    bool getBarrierCrossing();
    double getEuropeanUpInCallPrice(int nReps);
    double operator()(int nReps);

    // Members
    std::vector<double> thisPath;
    int nInt;
    double strike;
    double barrier;
    double spot;
    double vol;
    double r;
    double expiry;
    bool barrierCrossed;
};

// Definition of constructor
EuropeanUpInCall::EuropeanUpInCall(
    int nInt_,
    double strike_,
    double barrier_,
    double spot_,
    double vol_,
    double r_,
    double expiry_
) {
    nInt = nInt_;
    strike = strike_;
    barrier = barrier_;
    spot = spot_;
    vol = vol_;
    r = r_;
    expiry = expiry_;
    generatePath();
    getBarrierCrossing();
}

// Method definition
void EuropeanUpInCall::generatePath() {
    double thisDrift = (r * expiry - 0.5 * vol * vol * expiry) / double(nInt);
    double cumShocks = 0;
    thisPath.clear();

    for(int i = 0; i < nInt; i++) {
        cumShocks += (thisDrift + vol * sqrt(expiry / double(nInt)) * getOneGaussianByBoxMueller());
        thisPath.push_back(spot * exp(cumShocks));
    }
}

// Method to determine if the barrier is crossed during the path
bool EuropeanUpInCall::getBarrierCrossing() {
    barrierCrossed = false;
    for(int i = 0; i < nInt; i++) {
        if (thisPath[i] >= barrier) {
            barrierCrossed = true;
            break;
        }
    }
    return barrierCrossed;
}

// Overloaded method to get the European up-and-in call option price
double EuropeanUpInCall::getEuropeanUpInCallPrice(int nReps) {
    double rollingSum = 0.0;

    for(int i = 0; i < nReps; i++) {
        generatePath();
        if (getBarrierCrossing()) {
            // Payoff only if the barrier is crossed
            rollingSum += (thisPath[nInt-1] > strike) ? (thisPath[nInt-1] - strike) : 0;
        }
    }

    return double(exp(-r*expiry) * rollingSum) / double(nReps);
}

// Overloaded operator ()
double EuropeanUpInCall::operator()(int nReps) {
    return getEuropeanUpInCallPrice(nReps);
}

int main() {
    // Example usage
    int nInt = 1000;
    double strike = 100.0;
    double barrier = 90.0;
    double spot = 95.0;
    double vol = 0.2;
    double r = 0.05;
    double expiry = 1.0;
    int nReps = 10000;

    EuropeanUpInCall upInCallOption(nInt, strike, barrier, spot, vol, r, expiry);
    double optionPrice = upInCallOption(nReps);

    std::cout << "European Up-and-In Call Option Price: " << optionPrice << std::endl;

    return 0;
}
