#include<iostream>
#include<cmath>
#include"getOneGaussianByBoxMueller.h"
#include"EuropeanUpInCall.h"

// Definition of constructor
EuropeanUpInCall::EuropeanUpInCall(
    int nInt_,
    double strike_,
    double barrier_,
    double spot_,
    double vol_,
    double r_,
    double expiry_) {
    nInt = nInt_;
    strike = strike_;
    barrier = barrier_;
    spot = spot_;
    vol = vol_;
    r = r_;
    expiry = expiry_;
    generatePath();
    getBarrierCrossing();
}

// Method definition
void EuropeanUpInCall::generatePath() {
    double thisDrift = (r * expiry - 0.5 * vol * vol * expiry) / double(nInt);
    double cumShocks = 0;
    thisPath.clear();

    for(int i = 0; i < nInt; i++) {
        cumShocks += (thisDrift + vol * sqrt(expiry / double(nInt)) * getOneGaussianByBoxMueller());
        thisPath.push_back(spot * exp(cumShocks));
    }
}

// Method to determine if the barrier is crossed during the path
bool EuropeanUpInCall::getBarrierCrossing() {
    barrierCrossed = false;
    for(int i = 0; i < nInt; i++) {
        if (thisPath[i] >= barrier) {
            barrierCrossed = true;
            break;
        }
    }
    return barrierCrossed;
}

// Overloaded method to get the European up-and-in call option price
double EuropeanUpInCall::getEuropeanUpInCallPrice(int nReps) {
    double rollingSum = 0.0;

    for(int i = 0; i < nReps; i++) {
        generatePath();
        if (getBarrierCrossing()) {
            // Payoff only if the barrier is crossed
            rollingSum += (thisPath[nInt-1] > strike) ? (thisPath[nInt-1] - strike) : 0;
        }
    }

    return double(exp(-r*expiry) * rollingSum) / double(nReps);
}

// Overloaded operator ()
double EuropeanUpInCall::operator()(int nReps) {
    return getEuropeanUpInCallPrice(nReps);
}
