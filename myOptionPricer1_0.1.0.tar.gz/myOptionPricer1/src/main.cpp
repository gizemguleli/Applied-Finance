#include <Rcpp.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace Rcpp;
using std::vector;

class EuropeanUpInCall {
public:
    EuropeanUpInCall(int nInt_, double strike_, double barrier_, double spot_, double vol_, double r_, double expiry_);
    ~EuropeanUpInCall() {};

    void generatePath();
    bool getBarrierCrossing();
    double getEuropeanUpInCallPrice(int nReps);
    double operator()(int nReps);

    std::vector<double> thisPath;
    int nInt;
    double strike, barrier, spot, vol, r, expiry;
    bool barrierCrossed;
};

EuropeanUpInCall::EuropeanUpInCall(int nInt_, double strike_, double barrier_, double spot_, double vol_, double r_, double expiry_) {
    nInt = nInt_;
    strike = strike_;
    barrier = barrier_;
    spot = spot_;
    vol = vol_;
    r = r_;
    expiry = expiry_;
    generatePath();
    getBarrierCrossing();
}

void EuropeanUpInCall::generatePath() {
    double thisDrift = (r * expiry - 0.5 * vol * vol * expiry) / double(nInt);
    double cumShocks = 0;
    thisPath.clear();

    for(int i = 0; i < nInt; i++) {
        cumShocks += (thisDrift + vol * sqrt(expiry / double(nInt)) * R::rnorm(0, 1));
        thisPath.push_back(spot * exp(cumShocks));
    }
}

bool EuropeanUpInCall::getBarrierCrossing() {
    barrierCrossed = false;
    for(int i = 0; i < nInt; i++) {
        if (thisPath[i] >= barrier) {
            barrierCrossed = true;
            break;
        }
    }
    return barrierCrossed;
}

double EuropeanUpInCall::getEuropeanUpInCallPrice(int nReps) {
    double rollingSum = 0.0;

    for(int i = 0; i < nReps; i++) {
        generatePath();
        if (getBarrierCrossing()) {
            rollingSum += (thisPath[nInt-1] > strike) ? (thisPath[nInt-1] - strike) : 0;
        }
    }

    return double(exp(-r * expiry) * rollingSum) / double(nReps);
}

double EuropeanUpInCall::operator()(int nReps) {
    return getEuropeanUpInCallPrice(nReps);
}

// [[Rcpp::export]]
double getEuropeanUpInCallPrice(int nInt = 500,
                              double spot = 140,
                              double strike = 150,
                              double vol = 0.24,
                              double r = 0.07,
                              double expiry = 0.75,
                              double barrier = 160,
                              int nReps = 1000) {

    // Set the seed
    srand(time(NULL));

    // Create a new instance of the class
    EuropeanUpInCall myOption(nInt, strike, barrier, spot, vol, r, expiry);

    // Call the method to get option price
    double price = myOption.getEuropeanUpInCallPrice(nReps);

    // Return option price
    return price;
}
